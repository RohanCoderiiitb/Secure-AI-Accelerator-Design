#!/usr/bin/env python3
"""
run_cpa_shuffle.py -- does shuffling lower the CORRELATION between the
power at each cycle and the value being processed?  (correlation / CPA
view, the attacker's view; TVLA only asks whether a leak exists)

Inputs (both written by the same `make shuffle_tvla` run):
  --npz     traces/<tag>.npz            per-cycle power of every trace
  --values  traces/<tag>_values.csv     per trace: acc0..acc7 in ARRIVAL
                                        order, issue0..issue7 = slot the
                                        shuffler actually sent at each
                                        issue step (from +VALLOG=1)

Only traces of the RANDOM group are used (the fixed group repeats the
same values, so it carries no correlation).

For every power signal (P_reg / P_comb / P_tot ...), every clock cycle c
and every position k it computes Pearson correlation rho between the
power at cycle c and a leakage model of a value:

  ARRIVAL view  value = the k-th value that ARRIVED.  This is what an
                attacker can use: the arrival order is known, the
                shuffle order is not.
  ISSUE view    value = the value the shuffler sent to the core at issue
                step k.  Only possible because the testbench logged the
                secret order; it shows the leak that is really there.

Leakage models (value v = acc + bias, product p = v * m0):
  --model acc      Hamming weight of v (32 bit)
  --model prod     Hamming weight of p (64 bit)
  --model hd_acc   Hamming DISTANCE between v and the PREVIOUS value in the
                   same sequence (arrival sequence for the ARRIVAL view,
                   issue sequence for the ISSUE view) -- registers that are
                   overwritten value after value leak this way
  --model hd_prod  same, on p

Reading the result:
  * cycles where the ARRIVAL view is high  -> not protected by shuffling
    (e.g. values written into the buffer in arrival order)
  * cycles where the ISSUE view is high but the ARRIVAL view is low
    -> shuffling hid WHEN the value is processed: the teammate's point
  * traces an attacker needs, from |rho| (Mangard's rule, 99.99%):
        N = 3 + 8 * (3.719 / ln((1+rho)/(1-rho)))^2

Outputs (--plot PREFIX):
  PREFIX__cpa__heatmap.png    |rho| per (position, cycle), both views
  PREFIX__cpa__max-rho.png    max |rho| per cycle, ARRIVAL vs ISSUE
  and a per-cycle table on stdout (+ --csv).
"""
import argparse
import csv
import math
import sys

import numpy as np

BIAS = 137
M0 = 0x4E8B1C00


def hw(v, bits):
    return bin(v & ((1 << bits) - 1)).count("1")


def word(acc, model):
    b = acc + BIAS
    if model in ("acc", "hd_acc"):
        return b & 0xFFFFFFFF, 32
    return (b * M0) & 0xFFFFFFFFFFFFFFFF, 64


def leak_seq(seq, model):
    """leakage of every element of a value sequence (one trace)."""
    out, prev = [], 0
    for v in seq:
        w, bits = word(int(v), model)
        out.append(hw(w ^ prev, bits) if model.startswith("hd") else hw(w, bits))
        prev = w
    return out


def corr_cols(X, Y):
    """Pearson correlation of every column of X (n x a) with every column
    of Y (n x b) -> (a x b)."""
    X = X - X.mean(axis=0)
    Y = Y - Y.mean(axis=0)
    sx = np.sqrt((X * X).sum(axis=0))
    sy = np.sqrt((Y * Y).sum(axis=0))
    num = X.T @ Y
    den = np.outer(sx, sy)
    with np.errstate(invalid="ignore", divide="ignore"):
        r = np.where(den > 0, num / den, 0.0)
    return r


def traces_needed(rho):
    rho = min(abs(rho), 0.999999)
    if rho < 1e-6:
        return float("inf")
    return 3 + 8 * (3.719 / math.log((1 + rho) / (1 - rho))) ** 2


def load_npz(path, n_rows, want_keys, group_key):
    z = np.load(path, allow_pickle=True)
    keys = list(z.keys())
    # power signals
    if want_keys:
        pkeys = want_keys
    else:
        two_d = [k for k in keys if getattr(z[k], "ndim", 0) == 2]
        pref = [k for k in two_d if any(s in k.lower() for s in ("reg", "comb", "tot"))]
        pkeys = pref or two_d
    if not pkeys:
        sys.exit(f"[CPA] no 2-D power arrays in {path}; keys = {keys}. Use --trace-keys.")
    power = {}
    for k in pkeys:
        a = np.asarray(z[k], dtype=float)
        if a.shape[0] != n_rows and a.shape[1] == n_rows:
            a = a.T
        if a.shape[0] != n_rows:
            sys.exit(f"[CPA] {k}: {a.shape[0]} traces in the npz but {n_rows} lines in the values file")
        power[k] = a
    # group labels (only used as a consistency check)
    grp = None
    cands = [group_key] if group_key else [k for k in keys if k.lower() in
                                           ("group", "groups", "grp", "label", "labels", "y")]
    for k in cands:
        if k in keys and np.asarray(z[k]).ndim == 1 and len(z[k]) == n_rows:
            grp = np.asarray(z[k]).astype(int)
            break
    return power, grp, keys


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--npz", required=True)
    ap.add_argument("--values", required=True)
    ap.add_argument("--model", choices=["acc", "prod", "hd_acc", "hd_prod"], default="acc")
    ap.add_argument("--plot", required=True, help="output file prefix")
    ap.add_argument("--csv", default=None)
    ap.add_argument("--trace-keys", nargs="*", default=None, help="power arrays in the npz (auto if omitted)")
    ap.add_argument("--group-key", default=None, help="group label array in the npz (auto if omitted)")
    args = ap.parse_args()

    # ---- values file ----
    with open(args.values) as f:
        rows = list(csv.DictReader(f))
    if not rows:
        sys.exit("[CPA] empty values file")
    ops = sum(1 for c in rows[0] if c.startswith("acc"))
    acc = np.array([[int(r[f"acc{k}"]) for k in range(ops)] for r in rows], dtype=np.int64)
    iss = np.array([[int(r[f"issue{k}"]) for k in range(ops)] for r in rows], dtype=np.int64)
    rnd = np.array([int(r["random"]) for r in rows], dtype=int)
    grp_csv = np.array([int(r["group"]) for r in rows], dtype=int)
    n = len(rows)

    power, grp_npz, keys = load_npz(args.npz, n, args.trace_keys, args.group_key)
    if grp_npz is not None and not np.array_equal(grp_npz, grp_csv):
        sys.exit("[CPA] group labels in the npz and the values file differ -- "
                 "they are not from the same run (rerun make shuffle_tvla)")

    sel = rnd == 1
    if (iss[sel] < 0).any():
        sys.exit("[CPA] some traces have an incomplete issue order")
    nr = int(sel.sum())
    print(f"[CPA] {n} traces, {nr} with random values used; model = {args.model}; "
          f"power keys = {list(power)}")

    seq_arr = acc[sel]                                            # arrival order
    seq_iss = np.take_along_axis(acc[sel], iss[sel], axis=1)      # issue order
    L_arr = np.array([leak_seq(r, args.model) for r in seq_arr], dtype=float)
    L_iss = np.array([leak_seq(r, args.model) for r in seq_iss], dtype=float)

    res = {}
    for k, P in power.items():
        Ps = P[sel]
        res[k] = (np.abs(corr_cols(L_arr, Ps)), np.abs(corr_cols(L_iss, Ps)))

    # ---- table ----
    first = list(power)[-1]                                       # usually P_tot
    ra, ri = res[first]
    ncyc = ra.shape[1]
    lines = []
    print(f"\n[CPA] per cycle, signal {first}: max |rho| over the {ops} positions")
    print(f"  {'cycle':>5} {'ARRIVAL':>9} {'ISSUE':>9} {'traces needed (arrival)':>24} {'(issue)':>10}")
    for c in range(ncyc):
        a, i = ra[:, c].max(), ri[:, c].max()
        na, ni = traces_needed(a), traces_needed(i)
        fa = f"{na:,.0f}" if math.isfinite(na) else "-"
        fi = f"{ni:,.0f}" if math.isfinite(ni) else "-"
        print(f"  {c:>5} {a:>9.3f} {i:>9.3f} {fa:>24} {fi:>10}")
        lines.append([c, f"{a:.4f}", f"{i:.4f}", fa, fi])
    if args.csv:
        with open(args.csv, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["cycle", "max_rho_arrival", "max_rho_issue", "traces_arrival", "traces_issue"])
            w.writerows(lines)

    # ---- plots ----
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    nk = len(power)
    vmax = max(max(a.max(), i.max()) for a, i in res.values())
    fig, axs = plt.subplots(nk, 2, figsize=(13, 2.6 * nk + 0.8), squeeze=False)
    for r_, (k, (a, i)) in enumerate(res.items()):
        for c_, (m, ttl) in enumerate([(a, "ARRIVAL order (what an attacker knows)"),
                                        (i, "ISSUE order (true shuffled order)")]):
            ax = axs[r_][c_]
            im = ax.imshow(m, aspect="auto", origin="lower", vmin=0, vmax=vmax, cmap="viridis")
            ax.set_ylabel(f"{k}\nposition")
            if r_ == 0:
                ax.set_title(ttl)
            if r_ == nk - 1:
                ax.set_xlabel("clock cycle within capture window")
    fig.colorbar(im, ax=axs, shrink=0.8, label="|correlation|")
    fig.suptitle("Correlation of power with each value, shuffled requantizer")
    fig.savefig(f"{args.plot}__cpa__heatmap.png", dpi=150, bbox_inches="tight")
    plt.close(fig)

    fig, axs = plt.subplots(nk, 1, figsize=(10, 2.6 * nk + 0.8), squeeze=False, sharex=True)
    for r_, (k, (a, i)) in enumerate(res.items()):
        ax = axs[r_][0]
        ax.plot(a.max(axis=0), label="ARRIVAL order (attacker)", color="tab:red")
        ax.plot(i.max(axis=0), label="ISSUE order (true)", color="tab:blue", linestyle="--")
        ax.set_ylabel(f"max |rho| ({k})")
        ax.grid(alpha=0.3)
        if r_ == 0:
            ax.legend()
    axs[-1][0].set_xlabel("clock cycle within capture window")
    fig.suptitle("Best correlation per cycle: arrival order vs true issue order")
    fig.savefig(f"{args.plot}__cpa__max-rho.png", dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"\n[CPA] plots: {args.plot}__cpa__heatmap.png, {args.plot}__cpa__max-rho.png")


if __name__ == "__main__":
    main()
