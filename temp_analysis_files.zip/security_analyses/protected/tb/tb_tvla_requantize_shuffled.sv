`timescale 1ns/1ps
//=====================================================================
// tb_tvla_requantize_shuffled.sv -- TVLA dataset generation for the
//                                   shuffled (unmasked) requantizer
//                                   (protected_designs/source/requantize_shuffled.sv)
//
// Same experiment as tb_tvla_requantize_masked.sv, so the three
// requantizers (plain, masked, shuffled) are directly comparable:
//   * fixed/random contrast on acc_in (the accumulated dot product)
//   * OPS = D = 8 values per trace, back to back = one full batch
//   * bias = 137, m0 = 0x4E8B1C00 (~0.614 Q0.31), shift = 38: the SAME
//     layer constants as tb_tvla_accelerator.sv, identical in both groups
//   * acc = dot product of 4 random INT8 activations and 4 random INT8
//     weights, the same values the 4x4 accelerator produces (about 98% of
//     outputs land in range, 2% saturate)
//   * the FIXED group sends the same 8 values in the same arrival order
//     every trace; the shuffler then processes them in a fresh random
//     order every trace
//   * the DUT is requantize_shuffled_top: the shuffler WITH its own
//     random number generator. The WHOLE u_dut is dumped: generator,
//     input buffer, random picker, plain core, reorder buffer / slot
//     index output
//
// TVLA_TARGET: "act" only.
// Plusargs: +NTRACES +SEED +MODE=tvla|null +TVLA_TARGET +TAG +OUTDIR
//           +SHUF_OFF=1  control: same hardware, shuffling off (identity
//                        order) -> compare its |t| with the shuffled run
//           +VALLOG=1    also write <OUTDIR>/<TAG>_values.csv, one line per
//                        trace: the 8 acc values in ARRIVAL order and the
//                        order in which the shuffler actually ISSUED them
//                        (used by run_cpa_shuffle.py; does not change the
//                        simulation or the traces)
// Parameter: INORDER (1 = results restored to arrival order, 0 = results
//            leave in shuffled order with their slot index)
//=====================================================================
module tb_tvla_requantize_shuffled;

    localparam N    = 8;
    localparam ACCW = 32;
    localparam MW   = 32;
    localparam SW   = 6;
    localparam D    = 8;
    localparam RW   = 16;
    parameter  INORDER = 1;

    localparam real CLK_NS = 10.0;

    localparam OPS     = D;                // one full batch per trace
    localparam LAT     = 2 * D + 4;        // last result of the batch is out by then (both modes)
    localparam CAPTURE = OPS + LAT + 2;
    localparam FLUSH   = 4;

    reg                    clk = 1'b0;
    reg                    reset_n, valid_in;
    reg  signed [ACCW-1:0] acc_in, bias_in;
    reg  signed [MW-1:0]   m0_in;
    reg  [SW-1:0]          shift_in;
    reg                    shuf_en = 1'b1;
    wire                   valid_out, sat, busy, ovf;
    wire [N-1:0]           q;
    wire [$clog2(D)-1:0]   idx;

    (* dont_touch = "yes" *)
    requantize_shuffled_top #(.N(N), .ACCW(ACCW), .MW(MW), .SW(SW), .D(D), .RW(RW), .INORDER(INORDER)) u_dut (
        .clk(clk), .reset_n(reset_n), .valid_in(valid_in), .acc_in(acc_in),
        .bias_in(bias_in), .m0_in(m0_in), .shift_in(shift_in),
        .flush_in(1'b0), .shuf_en(shuf_en),
        .valid_out(valid_out), .q_out(q), .sat_out(sat), .idx_out(idx),
        .busy(busy), .overflow(ovf));

    always #(CLK_NS/2.0) clk = ~clk;

    `include "sca_capture.vh"

    reg signed [ACCW-1:0] fix_acc [0:OPS-1];

    // same accumulator distribution as the full accelerator: one column of
    // the 4x4 array, i.e. a dot product of 4 random INT8 activations with
    // 4 random INT8 weights (|acc| <= 65536)
    function signed [ACCW-1:0] rand_acc(input integer dummy);
        reg [63:0] r;
        reg signed [7:0] a, w;
        reg signed [ACCW-1:0] s;
        integer j;
        begin
            r = xs64s(0);
            s = 0;
            for (j = 0; j < 4; j = j + 1) begin
                a = r[16*j +: 8];
                w = r[16*j + 8 +: 8];
                s = s + a * w;
            end
            rand_acc = s;
        end
    endfunction

    integer t, k, w, SHUF_OFF_I, VALLOG_I, vfd, icnt;
    reg signed [ACCW-1:0] cur_acc [0:OPS-1];
    integer               ord     [0:OPS-1];
    reg                   logging = 1'b0;

    // record the issue order: slot sent to the core at each issue cycle
    always @(posedge clk)
        if (logging && u_dut.u_shuf.iact && icnt < OPS) begin
            ord[icnt] = u_dut.u_shuf.idx;
            icnt      = icnt + 1;
        end
    reg grp, eff;
    reg signed [ACCW-1:0] ra;

    initial begin
        sca_get_config("requantize_shuffled");
        if (TVLA_TARGET != "act") begin
            $display("[SCA] FATAL: TVLA_TARGET=%0s -- use 'act'", TVLA_TARGET);
            $finish;
        end
        if (!$value$plusargs("SHUF_OFF=%d", SHUF_OFF_I)) SHUF_OFF_I = 0;
        shuf_en = (SHUF_OFF_I == 0);
        if (!$value$plusargs("VALLOG=%d", VALLOG_I)) VALLOG_I = 0;
        $display("[SHUF] shuf_en=%0d  D=%0d  INORDER=%0d  capture=%0d", shuf_en, D, INORDER, CAPTURE);
        if (VALLOG_I) begin
            vfd = $fopen({OUTDIR, "/", TAG, "_values.csv"}, "w");
            $fwrite(vfd, "trace,group,random");
            for (k = 0; k < OPS; k = k + 1) $fwrite(vfd, ",acc%0d", k);
            for (k = 0; k < OPS; k = k + 1) $fwrite(vfd, ",issue%0d", k);
            $fwrite(vfd, "\n");
        end

        bias_in  = 32'sd137;
        m0_in    = 32'sh4E8B_1C00;
        shift_in = 6'd38;

        for (k = 0; k < OPS; k = k + 1) fix_acc[k] = rand_acc(0);

        $dumpfile({OUTDIR, "/", TAG, ".vcd"});
        $dumpvars(0, u_dut);                       // SCOPE: the whole shuffled requantizer
        sca_open_meta("requantize_shuffled", CLK_NS, CAPTURE);

        reset_n = 1'b0; valid_in = 1'b0; acc_in = 0;
        repeat (4) @(posedge clk);
        reset_n = 1'b1;
        repeat (LAT + 6) @(posedge clk);

        for (t = 0; t < NTRACES; t = t + 1) begin
            grp = group_sched[t];
            eff = effective_random(grp);

            // ---- wait until the previous batch has fully left, untriggered ----
            @(negedge clk);
            valid_in = 1'b0; acc_in = 0;
            w = 0;
            while (busy && w < 1000) begin @(negedge clk); w = w + 1; end
            repeat (FLUSH) @(negedge clk);

            // ---- capture window: one batch in, all its results out ----
            icnt = 0; logging = 1'b1;
            for (k = 0; k < CAPTURE; k = k + 1) begin
                if (k < OPS) begin
                    ra = rand_acc(0);                // R5: always draw for both groups
                    if (!eff) ra = fix_acc[k];
                    acc_in   = ra;
                    cur_acc[k] = ra;
                    valid_in = 1'b1;
                end else begin
                    valid_in = 1'b0;
                    acc_in   = 0;
                end
                @(posedge clk);
                if (k == 0) sca_trace_begin;
                @(negedge clk);
            end
            sca_trace_end(grp);
            logging = 1'b0;
            if (VALLOG_I) begin
                $fwrite(vfd, "%0d,%0d,%0d", t, grp, eff);
                for (k = 0; k < OPS; k = k + 1) $fwrite(vfd, ",%0d", cur_acc[k]);
                for (k = 0; k < OPS; k = k + 1) $fwrite(vfd, ",%0d", (k < icnt) ? ord[k] : -1);
                $fwrite(vfd, "\n");
            end

            if (ovf) begin $display("[SCA] FATAL: shuffler overflow"); $finish; end
            if (t % 500 == 0)
                $display("[SCA] trace %0d / %0d  t=%0t", t, NTRACES, $time);
        end

        repeat (2) @(posedge clk);
        if (VALLOG_I) $fclose(vfd);
        sca_close_meta;
        $finish;
    end

endmodule
